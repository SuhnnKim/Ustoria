﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using wox.serial;

namespace TestWoxCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // uncomment method to test
            try {
                //TestCourseMain();
                
                //Product.main(null);
                //TestProductMain();
                
                //Student.main(null);
                //TestStudentMain();

                //TestArray.main(null);
                //TestArrayMain();

                //TestListCourses.main(null);
                //TestListCoursesMain();

                //TestMapCourses.main(null);
                //TestMapCoursesMain();

                //TestMultiArray.main(null);
                //TestMultiArrayMain();

                //TestReferences.main(null);
                TestReferencesMain();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.ToString());
            }
            Console.ReadKey();
        }

        static void TestCourseMain() {
            Course course_c = (Course)Easy.load("TestCourseCSharp.xml");
            Console.WriteLine(course_c + "\n");

            Course course_j = (Course)Easy.load("xml_by_java\\TestCourse.xml");
            Console.WriteLine(course_j);
        }

        static void TestProductMain()
        {
            Product[] products_c = (Product[])Easy.load("TestProductsCSharp.xml");
            foreach(Product p in products_c)
                Console.WriteLine(p);

            Console.WriteLine();

            Product[] products_j = (Product[])Easy.load("xml_by_java\\Products.xml");
            foreach(Product p in products_j)
                Console.WriteLine(p);
        }

        static void TestStudentMain() {
            Student student_c = (Student)Easy.load("TestStudentCSharp.xml");
            Console.WriteLine(student_c + "\n");

            Student student_j = (Student)Easy.load("xml_by_java\\TestStudent.xml");
            Console.WriteLine(student_j);
        }

        static void TestArrayMain()
        {
            TestArray arr_c = (TestArray)Easy.load("TestPrimitiveArraysCSharp.xml");
            Console.WriteLine(arr_c + "\n");

            TestArray arr_j = (TestArray)Easy.load("xml_by_java\\TestPrimitiveArrays.xml");
            Console.WriteLine(arr_j);
        }

        static void TestListCoursesMain()
        {
            ArrayList arr_c = (ArrayList)Easy.load("TestListCoursesCSharp.xml");
            //List<Course> arr_c = (List<Course>)Easy.load("TestListCoursesCSharp.xml"); // this does not work
            foreach(Course c in arr_c)
                Console.WriteLine(c);
            
            Console.WriteLine();

            ArrayList arr_j = (ArrayList)Easy.load("xml_by_java\\TestListCourses.xml");
            foreach(Course c in arr_j)
                Console.WriteLine(c);
        }

        static void TestMapCoursesMain()
        {
            Hashtable arr_c = (Hashtable)Easy.load("TestMapCoursesCSharp.xml");
            foreach (DictionaryEntry de in arr_c)
                Console.WriteLine(String.Format("{0}, {1}", de.Key, de.Value));

            Console.WriteLine();

            // Java.Map == C#.Hashtable so
            Hashtable arr_j = (Hashtable)Easy.load("xml_by_java\\TestMapCourses.xml");
            foreach (DictionaryEntry de in arr_j)
                Console.WriteLine(String.Format("{0}, {1}", de.Key, de.Value));
        }

        static void TestMultiArrayMain()
        {
            TestMultiArray arr_c = (TestMultiArray)Easy.load("TestMultiArraysCSharp.xml");
            TestMultiArray.printTestArray(arr_c);

            Console.WriteLine();

            TestMultiArray arr_j = (TestMultiArray)Easy.load("xml_by_java\\TestMultiArrays.xml");
            TestMultiArray.printTestArray(arr_j);
        }

        static void TestReferencesMain()
        {
            Product[] products_c = (Product[])Easy.load("TestReferencesCSharp.xml");
            foreach (Product p in products_c)
                Console.WriteLine(p);

            Console.WriteLine();

            Product[] products_j = (Product[])Easy.load("xml_by_java\\TestReferences.xml");
            foreach (Product p in products_j)
                Console.WriteLine(p);
        }

    }
}
